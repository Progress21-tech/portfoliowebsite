# Progress — Portfolio (ProbeTech)

A React + Vite portfolio site with a live 3D hero (React Three Fiber).

---

## Run it in GitHub Codespaces (no local setup needed)

### 1. Get these files into a GitHub repo
- Create a new repository on GitHub (e.g. `probetech-site`).
- Upload all these files/folders into it, keeping the same structure:
  ```
  probetech-site/
  ├── index.html
  ├── package.json
  ├── vite.config.js
  ├── .gitignore
  └── src/
      ├── main.jsx
      ├── App.jsx
      ├── index.css
      └── components/
          ├── Nav.jsx
          ├── Hero.jsx
          ├── Work.jsx
          ├── Sections.jsx
          └── useReveal.js
  ```

### 2. Open a Codespace
- On your repo page, click the green **Code** button → **Codespaces** tab → **Create codespace on main**.
- Wait ~1 minute for it to load VS Code in your browser.

### 3. Install and run (in the Codespace terminal)
```bash
npm install
npm run dev
```
- A popup will say a port is running — click **Open in Browser**. That's your site.

### 4. Edit and see changes live
- Change any file in `src/`, save, and the browser updates instantly (hot reload).

---

## Before you go live — replace the placeholders
- `src/components/Sections.jsx` → swap `hello@yourdomain.com` for your real email, and add real social links.
- `src/components/Work.jsx` → the case studies live in the `CASES` array; add live project URLs / tweak copy here.

## Deploy (when ready)
- Push to GitHub, then connect the repo to **Vercel** or **Netlify** — both auto-detect Vite. Build command: `npm run build`, output: `dist`.

## The 3D
- Lives in `src/components/Hero.jsx`. It's an amber particle field + a hoverable wireframe object.
- `dpr={[1, 2]}` caps resolution for mobile performance — keep it.
- To experiment: change `count` in `ParticleField`, or swap `icosahedronGeometry` for `torusKnotGeometry` / `octahedronGeometry`.
