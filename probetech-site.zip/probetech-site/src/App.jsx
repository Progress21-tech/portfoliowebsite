import React from "react";
import Nav from "./components/Nav.jsx";
import Hero from "./components/Hero.jsx";
import Work from "./components/Work.jsx";
import { Approach, About, Contact, Footer } from "./components/Sections.jsx";

export default function App() {
  return (
    <>
      <Nav />
      <Hero />
      <Work />
      <Approach />
      <About />
      <Contact />
      <Footer />
    </>
  );
}
