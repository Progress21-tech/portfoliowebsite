import React from "react";
import useReveal from "./useReveal";

const CASES = [
  {
    tag: "Marketing site · Client",
    name: "EventFlow",
    stack: ["React", "TypeScript", "Framer Motion", "Vercel"],
    lead: "An event-marketing company needed a site that felt as premium as the events they run.",
    rows: [
      ["Built", "A fast, motion-driven portfolio & case-studies site where animation guides attention without slowing the experience down.", false],
      ["Result", "A brand presence that matches their work — and converts visitors into enquiries.", true],
    ],
  },
  {
    tag: "Full platform · Health",
    name: "MediConnect",
    stack: ["React/Vite", "Node/Express", "Supabase", "React Native"],
    lead: "Health providers were juggling patient records across paper and scattered tools.",
    rows: [
      ["Built", "A complete EMR platform — web app plus a mobile app — with secure authentication and a production backend.", false],
      ["Shows", "End-to-end capability — architecting and shipping something genuinely complex, not just styling a page.", true],
    ],
  },
  {
    tag: "Custom CMS · Client",
    name: "ProbeTech CMS",
    stack: ["React/Vite", "Node/Express", "Supabase", "Tiptap"],
    lead: "A client needed to manage their own content without calling a developer every time.",
    rows: [
      ["Built", "A custom CMS with role-based access and a rich-text editor, deployed to production on Render & Vercel.", false],
      ["Result", "A self-sufficient team — they update their own site, freeing up time and budget.", true],
    ],
  },
  {
    tag: "Product · Fintech",
    name: "KOLA",
    stack: ["Next.js", "Supabase", "AI scoring", "Product design"],
    lead: "Members of informal savings groups have no credit history — so lenders can't see them.",
    rows: [
      ["Built", "A credit-scoring platform that turns Ajo savings-group participation into a usable credit signal.", false],
      ["Shows", "Product instinct — starting from a real problem and building toward a real outcome.", true],
    ],
  },
];

function Case({ data }) {
  const [ref, shown] = useReveal();
  return (
    <article ref={ref} className={`case reveal ${shown ? "in" : ""}`}>
      <div className="case-left">
        <span className="tag">{data.tag}</span>
        <h3 className="case-name">{data.name}</h3>
        <div className="case-stack">
          {data.stack.map((s) => <span key={s} className="chip">{s}</span>)}
        </div>
      </div>
      <div className="case-right">
        <p className="lead">{data.lead}</p>
        {data.rows.map(([k, v, bold]) => (
          <div className="row" key={k}>
            <span className="k">{k}</span>
            <span className="v">{bold ? <b>{v}</b> : v}</span>
          </div>
        ))}
      </div>
    </article>
  );
}

export default function Work() {
  const [ref, shown] = useReveal();
  return (
    <section id="work">
      <div className="wrap">
        <div ref={ref} className={`sec-head reveal ${shown ? "in" : ""}`}>
          <span className="sec-num">01</span>
          <h2 className="sec-title">Selected <em>work</em></h2>
        </div>
        <div className="work-grid">
          {CASES.map((c) => <Case key={c.name} data={c} />)}
        </div>
      </div>
    </section>
  );
}
