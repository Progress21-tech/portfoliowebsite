import React from "react";
import useReveal from "./useReveal";

const STEPS = [
  ["/ 01", "Start from the problem", "I don't lead with technology. I figure out what the business actually needs — more customers, more credibility, a shipped idea — and build toward that."],
  ["/ 02", "Design & build, one person", "No handoff gaps. I handle the look and the code, so the final product matches the vision instead of drifting from it."],
  ["/ 03", "Fast, modern, mobile-first", "Built on a modern stack and tuned for speed — because most of your visitors are on a phone, and a slow site loses them."],
  ["/ 04", "Ship, then sharpen", "I get a working version live, then refine with real feedback — instead of polishing forever behind closed doors."],
];

const FACTS = [
  ["Role", "Designer & Developer"],
  ["Studio", "ProbeTech"],
  ["Based", "Lagos, Nigeria"],
  ["Frontend", "React · Next.js · TS · Tailwind"],
  ["Backend", "Node · Express · Supabase"],
  ["Motion", "Framer Motion · R3F"],
  ["Status", "Open to projects & roles"],
];

function Reveal({ as: Tag = "div", className = "", children }) {
  const [ref, shown] = useReveal();
  return <Tag ref={ref} className={`reveal ${shown ? "in" : ""} ${className}`}>{children}</Tag>;
}

export function Approach() {
  return (
    <section id="approach">
      <div className="wrap">
        <Reveal className="sec-head">
          <span className="sec-num">02</span>
          <h2 className="sec-title">How I <em>work</em></h2>
        </Reveal>
        <div className="pills">
          {STEPS.map(([num, title, body]) => (
            <Reveal key={title} className="pill">
              <span className="num">{num}</span>
              <h3>{title}</h3>
              <p>{body}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function About() {
  return (
    <section id="about">
      <div className="wrap">
        <Reveal className="sec-head">
          <span className="sec-num">03</span>
          <h2 className="sec-title">About</h2>
        </Reveal>
        <div className="about-grid">
          <Reveal className="about-copy">
            <p>I'm Progress — a designer and developer, and the founder of <em>ProbeTech</em>, a small web studio based in Lagos.</p>
            <p className="dim">I build for two kinds of people: businesses that need a site that brings in customers and looks credible, and founders who need an MVP shipped fast and well. The thread between them is the same — clean design, solid engineering, and a focus on the outcome rather than the feature list.</p>
            <p className="dim">My work ranges from polished marketing sites to full platforms like an EMR system and a fintech credit-scoring tool. I care about the intersection of design taste and product quality — making things that work as well as they look.</p>
          </Reveal>
          <Reveal className="about-facts">
            {FACTS.map(([k, v]) => (
              <div className="f" key={k}><span>{k}</span><span>{v}</span></div>
            ))}
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export function Contact() {
  return (
    <section id="contact">
      <div className="wrap">
        <Reveal>
          <p className="contact-big">Have something to<br /><em>build?</em></p>
          <a href="mailto:hello@yourdomain.com" className="contact-mail">hello@yourdomain.com</a>
          <div className="socials">
            <a href="#">LinkedIn</a>
            <a href="#">Instagram</a>
            <a href="#">TikTok</a>
            <a href="#">GitHub</a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer>
      <div className="wrap foot-in">
        <span>© 2026 Progress · ProbeTech</span>
        <span>Designed &amp; built in Lagos</span>
      </div>
    </footer>
  );
}
