import React, { useRef, useMemo, useState, Suspense } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";

// A field of particles that drifts and reacts to the mouse
function ParticleField({ count = 1400 }) {
  const points = useRef();
  const { viewport } = useThree();

  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3 + 0] = (Math.random() - 0.5) * 14;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 9;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 6;
    }
    return arr;
  }, [count]);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (!points.current) return;
    points.current.rotation.y = t * 0.04;
    points.current.rotation.x = Math.sin(t * 0.1) * 0.08;
    const mx = (state.pointer.x * viewport.width) / 14;
    const my = (state.pointer.y * viewport.height) / 14;
    points.current.rotation.y += mx * 0.04;
    points.current.rotation.x += -my * 0.04;
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.035}
        color="#e9a23b"
        sizeAttenuation
        transparent
        opacity={0.85}
        depthWrite={false}
      />
    </points>
  );
}

// A slowly rotating wireframe icosahedron as the hero object
function HeroObject() {
  const mesh = useRef();
  const [hovered, setHovered] = useState(false);

  useFrame((state, delta) => {
    if (!mesh.current) return;
    mesh.current.rotation.x += delta * 0.15;
    mesh.current.rotation.y += delta * 0.2;
    const target = hovered ? 1.15 : 1;
    mesh.current.scale.x += (target - mesh.current.scale.x) * 0.08;
    mesh.current.scale.y = mesh.current.scale.x;
    mesh.current.scale.z = mesh.current.scale.x;
  });

  return (
    <mesh
      ref={mesh}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      <icosahedronGeometry args={[1.6, 1]} />
      <meshBasicMaterial color={hovered ? "#f4f1ea" : "#e9a23b"} wireframe transparent opacity={0.6} />
    </mesh>
  );
}

export default function Hero() {
  return (
    <header className="hero" id="top">
      <div className="hero-canvas">
        <Canvas camera={{ position: [0, 0, 6], fov: 60 }} dpr={[1, 2]}>
          <Suspense fallback={null}>
            <ParticleField />
            <HeroObject />
          </Suspense>
        </Canvas>
      </div>
      <div className="hero-glow" />
      <div className="hero-content">
        <div className="eyebrow">Designer &amp; Developer · Lagos · ProbeTech</div>
        <h1>
          I design &amp; build websites and apps that{" "}
          <em>win customers</em> &amp; ship ideas.
        </h1>
        <p className="sub">
          From polished marketing sites for growing businesses to full product
          MVPs for founders — I handle the design and the build, end to end.
        </p>
        <div className="hero-cta">
          <a href="#work" className="btn btn-primary">See selected work →</a>
          <a href="#contact" className="btn btn-ghost">Start a project</a>
        </div>
      </div>
    </header>
  );
}
